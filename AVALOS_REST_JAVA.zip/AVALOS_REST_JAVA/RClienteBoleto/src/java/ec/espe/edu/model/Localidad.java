/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ec.espe.edu.model;

/**
 *
 * @author irina
 */
public class Localidad {
    private String CodigoLocalidad;
    private String CodigoEspectaculo;
    private String CodigoLocEsp;
    private String Precio;
    private String Disponibilidad;

    public Localidad() {
    }

    public Localidad(String CodigoLocalidad, String CodigoEspectaculo, String CodigoLocEsp, String Precio, String Disponibilidad) {
        this.CodigoLocalidad = CodigoLocalidad;
        this.CodigoEspectaculo = CodigoEspectaculo;
        this.CodigoLocEsp = CodigoLocEsp;
        this.Precio = Precio;
        this.Disponibilidad = Disponibilidad;
    }
    

    public String getCodigoLocalidad() {
        return CodigoLocalidad;
    }

    public void setCodigoLocalidad(String CodigoLocalidad) {
        this.CodigoLocalidad = CodigoLocalidad;
    }

    public String getCodigoEspectaculo() {
        return CodigoEspectaculo;
    }

    public void setCodigoEspectaculo(String CodigoEspectaculo) {
        this.CodigoEspectaculo = CodigoEspectaculo;
    }

    public String getCodigoLocEsp() {
        return CodigoLocEsp;
    }

    public void setCodigoLocEsp(String CodigoLocEsp) {
        this.CodigoLocEsp = CodigoLocEsp;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String Precio) {
        this.Precio = Precio;
    }

    public String getDisponibilidad() {
        return Disponibilidad;
    }

    public void setDisponibilidad(String Disponibilidad) {
        this.Disponibilidad = Disponibilidad;
    }
    
    
}
