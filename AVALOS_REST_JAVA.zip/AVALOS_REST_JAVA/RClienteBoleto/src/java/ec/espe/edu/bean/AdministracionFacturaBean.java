/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ec.espe.edu.bean;

import ec.espe.edu.WSClient.WebServiceClientController;
import ec.espe.edu.model.Factura;
import java.awt.Event;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author irina
 */
@ManagedBean
@ViewScoped
public class AdministracionFacturaBean {

    /**
     * Creates a new instance of AdministracionFacturaBean
     */
    public AdministracionFacturaBean() {
    }
    private WebServiceClientController wscc;    
    //Facturas
    private List<Factura> facturas;
    private List<Factura> facturasEscojidos;
    private Factura facturaSeleccionado;
    private Factura factura;
    private List<Integer> nombres;
//    private List<Detalle> detalles;
//    private Detalle detalle;
    //Banderas auxliares
    private Boolean flagBoton1;
    private Boolean enModificar;

    
     @PostConstruct
    public void inicializar() {
        wscc = new WebServiceClientController();
        facturas = wscc.obtenerFactura();
        facturasEscojidos = new ArrayList<>();
       // detalles = new ArrayList<>();
        factura = new Factura();
        flagBoton1 = true;
        enModificar = false;
    }

    public void onRowSelect(Event e) {
        flagBoton1 = false;
        factura = facturaSeleccionado;

    }

    public void onRowUnSelect(Event e) {
        flagBoton1 = true;
        facturaSeleccionado = new Factura();
        factura = new Factura();
    }

    public void enModificar() {
        enModificar = true;
        factura = facturaSeleccionado;
    }

    public void enCrear() {
        enModificar = false;
    }

    public List<Integer> inicalizarFacturas() {
        this.nombres = new ArrayList<Integer>();
        for (Factura art : this.facturas) {
            this.nombres.add(art.getFacCodigo());
        }
        return this.nombres;
    }

    public void completarCampos(SelectEvent event) {
        this.factura = new Factura();
        for (Factura arti : this.facturas) {
            if (arti.getFacCodigo().equals(event.getObject().toString())) {
                this.factura.setFacDetalle(arti.getFacDetalle());
                this.factura.setFacFecha(arti.getFacFecha());
                this.factura.setFacTotal(arti.getFacTotal());
            }
            
        }
    }

  

    public void cancelar() {
        factura = new Factura();
    }

    public List<Factura> getFacturas() {
        return facturas;
    }

    public void setFacturas(List<Factura> facturas) {
        this.facturas = facturas;
    }

    public Factura getFacturaSeleccionado() {
        return facturaSeleccionado;
    }

    public void setFacturaSeleccionado(Factura facturaSeleccionado) {
        this.facturaSeleccionado = facturaSeleccionado;
    }

    public Boolean getFlagBoton1() {
        return flagBoton1;
    }

    public void setFlagBoton1(Boolean flagBoton1) {
        this.flagBoton1 = flagBoton1;
    }

    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }

    public List<Integer> getNombres() {
        return nombres;
    }

    public void setNombres(List<Integer> nombres) {
        this.nombres = nombres;
    }

    public List<Factura> getFacturasEscojidos() {
        return facturasEscojidos;
    }

    public void setFacturasEscojidos(List<Factura> facturasEscojidos) {
        this.facturasEscojidos = facturasEscojidos;
    }
    
    
}
