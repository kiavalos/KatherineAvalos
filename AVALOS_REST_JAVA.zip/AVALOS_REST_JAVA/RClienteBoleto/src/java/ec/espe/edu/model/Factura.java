/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ec.espe.edu.model;

/**
 *
 * @author irina
 */
public class Factura {
    private Integer facCodigo;
    private String facDetalle;
    private String facFecha;
    private float facTotal;

    public Factura(Integer facCodigo, String facDetalle, String facFecha, float facTotal) {
        this.facCodigo = facCodigo;
        this.facDetalle = facDetalle;
        this.facFecha = facFecha;
        this.facTotal = facTotal;
    }

  

    public float getFacTotal() {
        return facTotal;
    }

    public void setFacTotal(float facTotal) {
        this.facTotal = facTotal;
    }
    
   
    public Factura() {
    }

    public Factura(Integer facCodigo) {
        this.facCodigo = facCodigo;
    }

    public Factura(Integer facCodigo, String facDetalle) {
        this.facCodigo = facCodigo;
        this.facDetalle = facDetalle;
    }

    public Integer getFacCodigo() {
        return facCodigo;
    }

    public void setFacCodigo(Integer facCodigo) {
        this.facCodigo = facCodigo;
    }

    public String getFacDetalle() {
        return facDetalle;
    }

    public void setFacDetalle(String facDetalle) {
        this.facDetalle = facDetalle;
    }

    public String getFacFecha() {
        return facFecha;
    }

    public void setFacFecha(String facFecha) {
        this.facFecha = facFecha;
    }

    @Override
    public String toString() {
        return "Factura{" + "facCodigo=" + facCodigo + ", facDetalle=" + facDetalle + ", facFecha=" + facFecha + ", facTotal=" + facTotal + '}';
    }

    
}
