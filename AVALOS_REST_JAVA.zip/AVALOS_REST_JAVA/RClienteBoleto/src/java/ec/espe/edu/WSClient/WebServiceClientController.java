/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ec.espe.edu.WSClient;

import ec.espe.edu.model.Factura;
import ec.espe.edu.model.Localidad;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author irina
 */
public class WebServiceClientController {
    private WSLocalidad wsca;
    private WSFactura wscp;
    
    public WebServiceClientController() {
        wsca = new WSLocalidad();
        wscp = new WSFactura();
    }


    public List<Localidad> obtenerLocalidad() {
        String articuloStr = wsca.obtenerLocalidad();
        List<Localidad> articulos = new ArrayList<>();
        String[] aux = articuloStr.split("¬");
        for (String parametro : aux) {
            String[] aux1 = parametro.split("\\*");
            switch (aux1[1]){
                case "1":
                    aux1[1]="JUANES";
                    break;
                 case "2":
                    aux1[1]="REIK";
                    break;
                  case "5":
                    aux1[1]="MELEDI";
                    break;  
                  case "6":
                    aux1[1]="TRIO COLONIAL";
                    break;
            }
            articulos.add(new Localidad(aux1[0], aux1[1], aux1[2], aux1[3], aux1[4]));
        }
        return articulos;
    }
    
    public List<Factura> obtenerFactura() {
        String articuloStr = wscp.obtenerFactura();
        List<Factura> articulos = new ArrayList<>();
        String[] aux = articuloStr.split("¬");
        for (String parametro : aux) {
            String[] aux1 = parametro.split("\\*");
            articulos.add(new Factura(Integer.parseInt(aux1[0]), aux1[2], aux1[1],Float.parseFloat(aux1[3])));
        }
        return articulos;
    }


    public void registarFactura(Factura factura) {
        
        wscp.create_JSON(factura);
    }

    public void modificarLocalidad(Localidad localidad) {
        wsca.edit_JSON(localidad, localidad.getCodigoLocEsp().toString());
    }

}