/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.espe.edu.bean;

import ec.espe.edu.WSClient.WebServiceClientController;
import ec.espe.edu.model.Factura;
import ec.espe.edu.model.Localidad;
import java.awt.Event;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author irina
 */
@ManagedBean
@ViewScoped
public class AdministracionLocalidadBean {

    /**
     * Creates a new instance of AdministracionLocalidadBean
     */
    private WebServiceClientController wscc;
    //Localidads
    private List<Localidad> localidades;
    private List<Localidad> localidadesEscojidos;
    private Localidad localidadSeleccionado;
    private Localidad localidad;
    private List<String> nombres;
    private Boolean flagBoton1;
    private Boolean enModificar=false;

    private String cantidad;
    
    public AdministracionLocalidadBean() {
    }

    @PostConstruct
    public void inicializar() {
        
        wscc = new WebServiceClientController();
         localidades = wscc.obtenerLocalidad();
        localidadesEscojidos = new ArrayList<>();
        // detalles = new ArrayList<>();
        localidad = new Localidad();
        flagBoton1 = true;
        
        enModificar = false;
    }

    public void onRowSelect(Event e) {
        flagBoton1 = false;
        localidad = localidadSeleccionado;

    }

    public void onRowUnSelect(Event e) {
        flagBoton1 = true;
        localidadSeleccionado = new Localidad();
        localidad = new Localidad();
    }

    public void enModificar() {
        enModificar = true;
        localidad = localidadSeleccionado;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    
    public void enCrear() {
        enModificar = false;
    }
    

    public List<String> inicalizarLocalidads() {
        this.nombres = new ArrayList<String>();
        for (Localidad art : this.localidades) {
            this.nombres.add(art.getCodigoEspectaculo());
        }
        return this.nombres;
    }

    public void completarCampos(SelectEvent event) {
        this.localidad = new Localidad();
        for (Localidad arti : this.localidades) {
            if (arti.getCodigoLocEsp().equals(event.getObject().toString())) {
                this.localidad.setCodigoEspectaculo(arti.getCodigoEspectaculo());
                this.localidad.setCodigoLocalidad(arti.getCodigoLocalidad());
                this.localidad.setDisponibilidad(arti.getDisponibilidad());
                this.localidad.setPrecio(arti.getPrecio());
            }
        }
    }

    /*
       public void registrarFactura(String fecha, String localidad, String espectaculo, String cantidad, String precio) {
           factura.setFacDetalle("Localidad: "+localidad+" Espectáculo: "+espectaculo+" Cantidad:"+cantidad+" Precio:"+precio);
           factura.setFacFecha(fecha);
           factura.setFacTotal(Integer.parseInt(cantidad)*Float.parseFloat(precio));
           wscc.registarFactura(factura);
           
           factura = new Factura();
           facturas = wscc.obtenerFactura();
           flagBoton1 = true;
        
       }
    */
    public void actualizarEventos(){
       wscc.modificarLocalidad(localidadSeleccionado);
       localidadSeleccionado = new Localidad();
        localidades = wscc.obtenerLocalidad();
        
        flagBoton1 = true;
    
    }
    public void modificarDisponibilidad(String fecha, String localidad, String espectaculo, int cantidad, String precio)  {
        int disponibilidad = Integer.parseInt(localidadSeleccionado.getDisponibilidad()) - cantidad;

        switch (localidadSeleccionado.getCodigoEspectaculo()) {
            case "JUANES":
                localidadSeleccionado.setCodigoEspectaculo("1");
                break;
            case "REIK":
                localidadSeleccionado.setCodigoEspectaculo("2");
                break;
            case "MELENDI":
                localidadSeleccionado.setCodigoEspectaculo("5");
                break;
            case "TRIO COLONIAL":
                localidadSeleccionado.setCodigoEspectaculo("6");
                break;
        }
        localidadSeleccionado.setDisponibilidad(disponibilidad + "");
       
       
         actualizarEventos();
        Factura factura= new Factura();
        factura.setFacDetalle("Localidad: "+localidad+" Espectáculo: "+espectaculo+" Cantidad:"+cantidad+" Precio:"+precio);
           factura.setFacFecha(fecha);
           factura.setFacTotal(cantidad*Float.parseFloat(precio));
           wscc.registarFactura(factura);
           
        
        

    }


    public void cancelar() {
        localidad = new Localidad();
    }

    public List<Localidad> getLocalidads() {
        return localidades;
    }

    public void setLocalidads(List<Localidad> localidades) {
        this.localidades = localidades;
    }

    public Localidad getLocalidadSeleccionado() {
        return localidadSeleccionado;
    }

    public void setLocalidadSeleccionado(Localidad localidadSeleccionado) {
        this.localidadSeleccionado = localidadSeleccionado;
    }

    public Boolean getFlagBoton1() {
        return flagBoton1;
    }

    public void setFlagBoton1(Boolean flagBoton1) {
        this.flagBoton1 = flagBoton1;
    }

    public Localidad getLocalidad() {
        return localidad;
    }

    public void setLocalidad(Localidad localidad) {
        this.localidad = localidad;
    }

    public List<String> getNombres() {
        return nombres;
    }

    public void setNombres(List<String> nombres) {
        this.nombres = nombres;
    }


    public List<Localidad> getLocalidadsEscojidos() {
        return localidadesEscojidos;
    }

    public void setLocalidadsEscojidos(List<Localidad> localidadesEscojidos) {
        this.localidadesEscojidos = localidadesEscojidos;
    }

}
