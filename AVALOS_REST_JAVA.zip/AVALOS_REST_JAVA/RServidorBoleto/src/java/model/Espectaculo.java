/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author irina
 */
@Entity
@Table(name = "espectaculo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Espectaculo.findAll", query = "SELECT e FROM Espectaculo e"),
    @NamedQuery(name = "Espectaculo.findByCodigo", query = "SELECT e FROM Espectaculo e WHERE e.codigo = :codigo"),
    @NamedQuery(name = "Espectaculo.findByNombre", query = "SELECT e FROM Espectaculo e WHERE e.nombre = :nombre"),
    @NamedQuery(name = "Espectaculo.findByFecha", query = "SELECT e FROM Espectaculo e WHERE e.fecha = :fecha"),
    @NamedQuery(name = "Espectaculo.findByLugar", query = "SELECT e FROM Espectaculo e WHERE e.lugar = :lugar")})
public class Espectaculo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CODIGO")
    private Integer codigo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Column(name = "FECHA")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "LUGAR")
    private String lugar;

    public Espectaculo() {
    }

    public Espectaculo(Integer codigo) {
        this.codigo = codigo;
    }

    public Espectaculo(Integer codigo, String nombre, Date fecha, String lugar) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.fecha = fecha;
        this.lugar = lugar;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigo != null ? codigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Espectaculo)) {
            return false;
        }
        Espectaculo other = (Espectaculo) object;
        if ((this.codigo == null && other.codigo != null) || (this.codigo != null && !this.codigo.equals(other.codigo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Espectaculo[ codigo=" + codigo + " ]";
    }
    
}
