/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author irina
 */
@Entity
@Table(name = "localidad_espectaculo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LocalidadEspectaculo.findAll", query = "SELECT l FROM LocalidadEspectaculo l"),
    @NamedQuery(name = "LocalidadEspectaculo.findByCodigoLocEsp", query = "SELECT l FROM LocalidadEspectaculo l WHERE l.codigoLocEsp = :codigoLocEsp"),
    @NamedQuery(name = "LocalidadEspectaculo.findByCodigoLocalidad", query = "SELECT l FROM LocalidadEspectaculo l WHERE l.codigoLocalidad = :codigoLocalidad"),
    @NamedQuery(name = "LocalidadEspectaculo.findByDisponibilidad", query = "SELECT l FROM LocalidadEspectaculo l WHERE l.disponibilidad = :disponibilidad"),
    @NamedQuery(name = "LocalidadEspectaculo.findByPrecio", query = "SELECT l FROM LocalidadEspectaculo l WHERE l.precio = :precio"),
    @NamedQuery(name = "LocalidadEspectaculo.findByCodigoEspectaculo", query = "SELECT l FROM LocalidadEspectaculo l WHERE l.codigoEspectaculo = :codigoEspectaculo")})
public class LocalidadEspectaculo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CODIGO_LOC_ESP")
    private Integer codigoLocEsp;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 11)
    @Column(name = "CODIGO_LOCALIDAD")
    private String codigoLocalidad;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DISPONIBILIDAD")
    private int disponibilidad;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PRECIO")
    private double precio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CODIGO_ESPECTACULO")
    private int codigoEspectaculo;

    public LocalidadEspectaculo() {
    }

    public LocalidadEspectaculo(Integer codigoLocEsp) {
        this.codigoLocEsp = codigoLocEsp;
    }

    public LocalidadEspectaculo(Integer codigoLocEsp, String codigoLocalidad, int disponibilidad, double precio, int codigoEspectaculo) {
        this.codigoLocEsp = codigoLocEsp;
        this.codigoLocalidad = codigoLocalidad;
        this.disponibilidad = disponibilidad;
        this.precio = precio;
        this.codigoEspectaculo = codigoEspectaculo;
    }

    public Integer getCodigoLocEsp() {
        return codigoLocEsp;
    }

    public void setCodigoLocEsp(Integer codigoLocEsp) {
        this.codigoLocEsp = codigoLocEsp;
    }

    public String getCodigoLocalidad() {
        return codigoLocalidad;
    }

    public void setCodigoLocalidad(String codigoLocalidad) {
        this.codigoLocalidad = codigoLocalidad;
    }

    public int getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(int disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCodigoEspectaculo() {
        return codigoEspectaculo;
    }

    public void setCodigoEspectaculo(int codigoEspectaculo) {
        this.codigoEspectaculo = codigoEspectaculo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoLocEsp != null ? codigoLocEsp.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LocalidadEspectaculo)) {
            return false;
        }
        LocalidadEspectaculo other = (LocalidadEspectaculo) object;
        if ((this.codigoLocEsp == null && other.codigoLocEsp != null) || (this.codigoLocEsp != null && !this.codigoLocEsp.equals(other.codigoLocEsp))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.LocalidadEspectaculo[ codigoLocEsp=" + codigoLocEsp + " ]";
    }
    
}
