-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-01-2017 a las 08:12:31
-- Versión del servidor: 5.7.14
-- Versión de PHP: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `boleteria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espectaculo`
--

CREATE TABLE `espectaculo` (
  `CODIGO` int(5) NOT NULL,
  `NOMBRE` varchar(200) NOT NULL,
  `FECHA` date NOT NULL,
  `LUGAR` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `espectaculo`
--

INSERT INTO `espectaculo` (`CODIGO`, `NOMBRE`, `FECHA`, `LUGAR`) VALUES
(1, 'JUANES', '2017-01-25', 'RUMINAHUI'),
(2, 'REIK', '2017-01-26', 'RUMINAHUI'),
(5, 'MELENDI', '2017-01-31', 'RUMINAHUI'),
(6, 'TRIO COLONIAL', '2017-01-20', 'RUMINAHUI'),
(9, 'SHAKIRA', '2017-01-27', 'RUMINAHUI');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `FAC_CODIGO` int(11) NOT NULL,
  `FAC_DETALLE` varchar(200) NOT NULL,
  `FAC_FECHA` date DEFAULT NULL,
  `FAC_TOTAL` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`FAC_CODIGO`, `FAC_DETALLE`, `FAC_FECHA`, `FAC_TOTAL`) VALUES
(1, '2 Entrada Reik', '2017-01-28', 100),
(2, 'Localidad: VIP Epectaculo: JUANES Cantidad:1 Precio:120.0', NULL, 120),
(3, 'Localidad: TRIBUNA Epectaculo: MELEDI Cantidad:2 Precio:50.0', NULL, 100),
(4, 'Localidad: VIP Epectaculo: JUANES Cantidad:5 Precio:120.0', NULL, 600),
(5, 'Localidad: TRIBUNA Epectaculo: MELEDI Cantidad:1 Precio:50.0', NULL, 50),
(6, 'Localidad: TRIBUNA EspectÃ¡culo: JUANES Cantidad:2 Precio:60.0', NULL, 120),
(7, 'Localidad: PALCO EspectÃ¡culo: REIK Cantidad:1 Precio:100.0', NULL, 100),
(8, 'Localidad: GENERAL EspectÃ¡culo: MELEDI Cantidad:2 Precio:40.0', NULL, 80),
(9, 'Localidad: TRIBUNA EspectÃ¡culo: JUANES Cantidad:1 Precio:60.0', NULL, 60);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidad_espectaculo`
--

CREATE TABLE `localidad_espectaculo` (
  `CODIGO_LOC_ESP` int(11) NOT NULL,
  `CODIGO_LOCALIDAD` varchar(11) NOT NULL,
  `DISPONIBILIDAD` int(11) NOT NULL,
  `PRECIO` double NOT NULL,
  `CODIGO_ESPECTACULO` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `localidad_espectaculo`
--

INSERT INTO `localidad_espectaculo` (`CODIGO_LOC_ESP`, `CODIGO_LOCALIDAD`, `DISPONIBILIDAD`, `PRECIO`, `CODIGO_ESPECTACULO`) VALUES
(1, 'VIP', 49, 120, 1),
(2, 'TRIBUNA', 494, 60, 1),
(3, 'GENERAL', 700, 40, 1),
(4, 'VIP', 100, 100, 5),
(5, 'TRIBUNA', 200, 50, 5),
(6, 'GENERAL', 200, 40, 5),
(7, 'VIP', 200, 100, 6),
(8, 'PALCO', 100, 200, 1),
(9, 'PALCO', 100, 100, 2),
(10, 'PALCO', 200, 300, 5),
(11, 'PALCO', 70, 100, 6),
(12, 'TRIBUNA', 200, 40, 2),
(13, 'GENERAL', 120, 40, 2),
(14, 'TRIBUNA', 450, 26, 6),
(15, 'GENERAL', 2050, 15, 6),
(16, 'VIP', 160, 130, 2),
(17, 'SILLAS', 500, 80, 1),
(18, 'SILLAS', 300, 100, 2),
(19, 'SILLAS', 80, 80, 5),
(20, 'SILLAS', 210, 40, 6);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `espectaculo`
--
ALTER TABLE `espectaculo`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`FAC_CODIGO`);

--
-- Indices de la tabla `localidad_espectaculo`
--
ALTER TABLE `localidad_espectaculo`
  ADD PRIMARY KEY (`CODIGO_LOC_ESP`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `espectaculo`
--
ALTER TABLE `espectaculo`
  MODIFY `CODIGO` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `FAC_CODIGO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `localidad_espectaculo`
--
ALTER TABLE `localidad_espectaculo`
  MODIFY `CODIGO_LOC_ESP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
